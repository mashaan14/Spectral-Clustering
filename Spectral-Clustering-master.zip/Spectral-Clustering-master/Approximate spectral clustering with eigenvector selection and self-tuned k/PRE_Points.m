load('Zelnik-Manor-Data.mat');
X = XX{1};
