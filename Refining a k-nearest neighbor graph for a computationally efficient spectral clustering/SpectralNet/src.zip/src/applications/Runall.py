# -*- coding: utf-8 -*-
"""
Created on Sun Jul 12 22:52:41 2020

@author: mals6571
"""


for r in range(10):
    exec(open("C:/Users/mals6571/Desktop/SpectralNet-master/src/applications/run.py").read())